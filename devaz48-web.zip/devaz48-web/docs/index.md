# Welcome!

Situs ini masih dalam tahap pengembangan beberapa fitur dan halaman pada situs ini masih memiliki banyak `Bug` dan `Error`

## Cara Untuk Navigasi

* Anda bisa gunakan menu pada sidebar disamping untuk melakukan navigasi antar halaman
* Test cd
